# Archived non-public headers

These headers were removed from the installed/public `include/` directory. They remain repository-internal or benchmark-only implementation artifacts and are archived for review traceability.

The sole public family header is `include/bignum_random.h`.
